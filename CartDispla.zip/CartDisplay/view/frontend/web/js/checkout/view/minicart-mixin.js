define([
    'jquery',
     'uiComponent',
     'mage/validation',
     'ko',
     'mage/storage',
     'mage/url',
     'mage/cookies',
     'Magento_Catalog/js/price-utils'
], function ($, Component, validation, ko, storage, urlBuilder, priceUtils) {
    'use strict';

    return function (Component) {
        return Component.extend({
           
            update: function (updatedCart) {
                var self = this;
                var data =updatedCart;
                if(!updatedCart.summary_count){
                    $('#minicar-data').empty();
                    $('#subtotal-mini-cart').empty();
                    $('#go-to-checkout').empty();
                    $('#mini-cart-custom-func').hide();
                }else{
                var linkUrl = urlBuilder.build('vdcstore/ajax/CartUpdate');
                var checkout = urlBuilder.build('checkout');
                require('Magento_Customer/js/customer-data').reload(['customer']);
                require(['jquery', 'jquery/ui'], function($){
                       _.each(updatedCart, function (value, key) {
                  }, this);

                var items= updatedCart['items'];      
                var content = "<form method='POST' action="+linkUrl+"><table><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr>"
                    $('#minicar-data').empty();
                    $('#subtotal-mini-cart').empty();
                    $('#go-to-checkout').empty();
                _.each(items, function (value, key) {  
                            var productPriceSubtotal=value.product_price_value*value.qty;
                            content += '<tr><input type="hidden" name="item_id['+value.item_id+']" value="'+value.item_id+'"><td>'+value.product_name+'</td> <td>'+value.product_price+'</td><td class="ButtonDecrFlex"> <button class="decrement-qty" type="button" onclick="var qty_el = this.nextElementSibling; var qty = parseInt(qty_el.value); qty_el.value = qty > 1 ? qty - 1 : 1;"><span>-</span></button><input type="number" name="item_qty['+value.item_id+']" id="qty" min="1" value="'+value.qty+'" title="Qty" class="input-text-qty" data-validate="{&quot;required-number&quot;:true,&quot;validate-item-quantity&quot;:{&quot;minAllowed&quot;:1,&quot;maxAllowed&quot;:10000}}">   <button class="increment-qty" type="button" onclick="var qty_el = this.previousElementSibling; var qty = parseInt(qty_el.value); qty_el.value = qty + 1;"><span>+</span></td><td>'+productPriceSubtotal+'</td></tr>';
                               }, this);  
                    content += "<button type='submit' title='Add & Continue ' class='action tocart primary'><span>Add & Continue</span></button></form></table>";
                    checkout="<a href="+checkout+"><button type='button' title='Go CheckOut' class='action tocart primary'><span>Go CheckOut</span></button></a>";
                    var subtotalPrice=updatedCart.subtotal;
                    $('#mini-cart-custom-func').show();
                    $('#minicar-data').append(content);           
                    $('#subtotal-mini-cart').append(subtotalPrice);           
                    $('#go-to-checkout').append(checkout);           
                 });
                    }
                return this._super();

            },
        });
    }
});