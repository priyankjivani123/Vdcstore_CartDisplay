var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/minicart': {
                'Vdcstore_CartDisplay/js/checkout/view/minicart-mixin': true
            }
        }
    }
};
