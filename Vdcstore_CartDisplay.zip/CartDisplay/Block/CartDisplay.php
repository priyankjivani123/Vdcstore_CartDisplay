<?php
namespace Vdcstore\CartDisplay\Block;

use Magento\Framework\App\RequestInterface;

class CartDisplay extends \Magento\Framework\View\Element\Template
{
	 protected $request;

	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		RequestInterface $request
	)
	{
		$this->request = $request;
		parent::__construct($context);
	}

	 public function getMyPostParams()
    {


        
        $postData = $this->request->getPost();

        
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
		$logger = new \Zend_Log();
		$logger->addWriter($writer);
		
		$logger->info('----------------- get daata --------------- ');	
		$logger->info(print_r($postData,true));			
	 				

    }
}