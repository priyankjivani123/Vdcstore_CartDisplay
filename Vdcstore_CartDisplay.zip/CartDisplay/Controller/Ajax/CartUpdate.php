<?php
 
namespace Vdcstore\CartDisplay\Controller\Ajax;
 
use Magento\Checkout\Model\Sidebar;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Response\Http;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Json\Helper\Data;
use Psr\Log\LoggerInterface;
use Magento\Checkout\Model\Cart;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Controller\ResultFactory; 

 
class CartUpdate extends Action
{
     /**
     * @var Sidebar
     */
     protected $sidebar;
 
     /**
     * @var LoggerInterface
     */
     protected $logger;
 
     /**
     * @var Data
     */
     protected $jsonHelper;
     
     /**
     * @var Cart
     */
     protected $cart;
 
     /**
     * @param Context $context
     * @param Sidebar $sidebar
     * @param LoggerInterface $logger
     * @param Data $jsonHelper
     * @codeCoverageIgnore
     */
     public function __construct(
         Context $context,
         Cart $cart,
         \Magento\Checkout\Model\Session $checkoutSession,
         Sidebar $sidebar,
         LoggerInterface $logger,
        Data $jsonHelper,
        ManagerInterface $messageManager,
        \Magento\Framework\View\Result\PageFactory $pageFactory,

      ) {
         $this->sidebar = $sidebar;
         $this->logger = $logger;
         $this->jsonHelper = $jsonHelper;
         $this->_checkoutSession = $checkoutSession;
         $this->cart = $cart;
         $this->messageManager = $messageManager;
         $this->_pageFactory = $pageFactory;
         parent::__construct($context);
     }
 
     /**
     * @return $this
     */
     public function execute()
     {
          $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

         $post = $this->getRequest()->getPostValue();


            try {
                foreach($post as $postvalue){
                    foreach($postvalue as $key=>$item){
                       $itemId=$post['item_id'][$key];
                        $itemQty=$post['item_qty'][$key];
                         $this->updateQuoteItem($itemId, $itemQty);
                            }
                           $this->messageManager->addSuccess(__("Cart Update Succesfully "));
                         $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                            return $resultRedirect;
                    }
                    } catch (LocalizedException $e) {
                             return $this->jsonResponse($e->getMessage());
                         } catch (\Exception $e) {
                             $this->logger->critical($e);
                             return $this->jsonResponse($e->getMessage());
                         }


     }
 
     /**
      * Update quote item
      *
      * @param int $itemId
      * @param int $itemQty
      * @throws LocalizedException
      * @return $this
      */
      public function updateQuoteItem($itemId, $itemQty)
      {
         $itemData = [$itemId => ['qty' => $itemQty]];
         $this->cart->updateItems($itemData)->save();
      }
 
     /**
      * Get quote object associated with cart. By default it is current customer session quote
      *
      * @return \Magento\Quote\Model\Quote
      */
      public function getQuote()
      {
         return $this->_checkoutSession->getQuote();
     }
 
 
     /**
     * Compile JSON response
     *
     * @param string $error
     * @return Http
     */
     protected function jsonResponse($error = '')
     {
         return $this->getResponse()->representJson(
         $this->jsonHelper->jsonEncode($this->sidebar->getResponseData($error))
          );
        }
    }